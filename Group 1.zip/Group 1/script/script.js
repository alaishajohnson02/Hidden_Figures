function changeText() {
    var btn = document.getElementById('funButton');
    btn.textContent = 'Thank you for visiting!';
}